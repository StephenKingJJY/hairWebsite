var express = require('express');
var fs = require("fs");
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

/* Now Introducing Hair */
function waitHair(path){
  if (fs.existsSync(path)) {
    return;
  }
  else {
    setTimeout(function() {
      //callback(null);
    }, 200);
    waitHair(path);
  }
}

router.post('/hair', function(req, res) {
  fs.writeFileSync('./webcache/message.in', req.body.op);
  waitHair("./webcache/message.out");
  var data = fs.readFileSync("./webcache/message.out","utf-8");
  res.render('index', { title: data });
});

router.get('/hello.hair', function(req, res) {
  var filename = '1_'+Date.now();
  fs.writeFileSync('./hair_cache/'+filename, req.query.op);
  waitHair('./hair_cache/out_cache/'+filename);
  fs.unlinkSync('./hair_cache/'+filename);
  res.sendfile('./hair_cache/html_cache/'+filename+'.html');
});

module.exports = router;
