//http://chancejs.com/index.html

var Chance = require('chance')
var chance = new Chance()

module.exports = chance