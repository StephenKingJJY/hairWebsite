module.exports.match = function (str,reg) {
    return str.match(reg)
}
module.exports.replace = function (str,reg,text) {
    return str.replace(reg,text)
}
module.exports.split = function (str,reg) {
    return str.split(reg)
}